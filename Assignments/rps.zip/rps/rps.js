var imgPlayer;
var btnRock;
var btnPaper;
var btnScissors;
var btnGo;

function init(){
	imgPlayer = document.getElementById("imgPlayer");
	btnRock = document.getElementById("btnRock");
	btnPaper = document.getElementById("btnPaper");
	btnScissors = document.getElementById("btnScissors");
}
	
function selectRock(){
	alert('rock');
}

function selectPaper(){
	alert('paper');
}

function selectScissors(){
	alert('scissors');
}

